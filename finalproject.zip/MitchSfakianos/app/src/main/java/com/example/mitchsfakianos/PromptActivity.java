package com.example.mitchsfakianos;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.mitchsfakianos.databinding.ActivityMainBinding;

public class PromptActivity extends AppCompatActivity {
    Button allow, deny;
    ItemDBHelper DB;

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        allow = (Button) findViewById(R.id.buttonAllow);
        deny = (Button) findViewById(R.id.buttonDeny);

        allow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // set check to true
                Boolean check = true;
                // redirect to the home page, send intent
                Intent homeScreenIntent = new Intent(PromptActivity.this, DatabaseActivity.class);
                homeScreenIntent.putExtra("check",check);
                startActivity(homeScreenIntent);
            }
        });

        deny.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // set check to false
                Boolean check = false;
                // redirect to the home page, send intent
                Intent homeScreenIntent = new Intent(PromptActivity.this, DatabaseActivity.class);
                homeScreenIntent.putExtra("check",check);
                startActivity(homeScreenIntent);
            }
        });
    }
}