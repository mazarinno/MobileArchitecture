package com.example.mitchsfakianos;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    ItemDBHelper mDatabaseHelper;
    private Button btnAdd, btnBack;
    private EditText itemName, amount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        itemName = (EditText) findViewById(R.id.stockItem);
        btnAdd = (Button) findViewById(R.id.buttonEditFinal);
        btnBack = (Button) findViewById(R.id.buttonBack);
        mDatabaseHelper = new ItemDBHelper(this);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newEntryName = itemName.getText().toString();
                String newEntryAmount = amount.getText().toString();
                if (itemName.length() != 0 && amount.length() != 0) {
                    if (amount.getText().toString().matches("[0-9]+")) {
                        AddData(newEntryName, newEntryAmount);
                        itemName.setText("");
                        amount.setText("");

                        Intent intent = new Intent(AddActivity.this, DatabaseActivity.class);
                        startActivity(intent);
                    } else {
                        toastMessage("Amount must be in digits");
                    }
                } else {
                    toastMessage("Fields must not be empty");
                }

            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddActivity.this, DatabaseActivity.class);
                startActivity(intent);
            }
        });

    }

    public void AddData(String newEntryName, String newEntryAmount) {
        boolean insertData = mDatabaseHelper.addData(newEntryName, newEntryAmount);

        if (insertData) {
            toastMessage("Data Successfully Inserted!");
        } else {
            toastMessage("Something went wrong");
        }
    }

    private void toastMessage(String message){
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }
}