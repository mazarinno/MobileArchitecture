package com.example.mitchsfakianos;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class EditActivity extends AppCompatActivity {

    private static final String TAG = "EditActivity";

    private Button btnEdit,btnDelete, btnBack;
    private EditText editable_item, editable_amount;

    ItemDBHelper mDatabaseHelper;

    private String selectedName, selectedAmount;
    private int selectedID;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        btnEdit = (Button) findViewById(R.id.buttonEditFinal);
        btnDelete = (Button) findViewById(R.id.buttonDelete);
        btnBack = (Button) findViewById(R.id.buttonBack);
        editable_item = (EditText) findViewById(R.id.stockItem);
        editable_amount = (EditText) findViewById(R.id.amount);
        mDatabaseHelper = new ItemDBHelper(this);

        //get the intent extra from the ListDataActivity
        Intent receivedIntent = getIntent();

        //now get the itemID we passed as an extra
        selectedID = receivedIntent.getIntExtra("id",-1); //NOTE: -1 is just the default value

        //now get the name we passed as an extra
        selectedName = receivedIntent.getStringExtra("name");
        selectedAmount = receivedIntent.getStringExtra("amount");

        //set the text to show the current selected name
        editable_item.setText(selectedName);
        editable_amount.setText(selectedAmount);

        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String item = editable_item.getText().toString();
                String amount = editable_amount.getText().toString();
                if(!item.equals("") && !amount.equals("")){
                    if (amount.matches("[0-9]+")) {
                        mDatabaseHelper.updateName(item,selectedID,selectedName, amount);

                        Intent intent = new Intent(EditActivity.this, DatabaseActivity.class);
                        startActivity(intent);
                    } else {
                        toastMessage("Amount must be in digits");
                    }
                }else{
                    toastMessage("You must enter a name");
                }
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDatabaseHelper.deleteItem(selectedID,selectedName);
                editable_item.setText("");
                editable_amount.setText("");
                toastMessage("removed from database");

                Intent intent = new Intent(EditActivity.this, DatabaseActivity.class);
                startActivity(intent);
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EditActivity.this, DatabaseActivity.class);
                startActivity(intent);
            }
        });

    }

    private void toastMessage(String message){
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }
}